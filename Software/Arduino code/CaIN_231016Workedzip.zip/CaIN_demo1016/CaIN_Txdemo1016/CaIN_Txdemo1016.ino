#define CaINTxGPIO PIO_PC23B_PWML6  //	DigitalPin 7 -> PC23 PWML6_PC23 => PWM_CH6
#define CaINRxGPIO 6
#define CaINSwitchGPIO 4
#define OnRadioFlag HIGH
#define OffRadioFlag LOW
// CTRL (CaINSwitchGPIO) = 1 -> Antenna connect to Tx
// CTRL (CaINSwitchGPIO) = 0 -> Antenna connect to Rx


// ------------------------------------------------------------------------
// Function declarations
// ------------------------------------------------------------------------
bool Enable_CarrierPWM(uint8_t Period, uint8_t Duty);
bool Disable_CarrierPWM(void);
void Ascii_to_BinaryAarray(char ascii, uint8_t arr[8]);
bool Send_load(uint8_t start[], bool state);
void Send_bytes(byte byteload0, byte byteload1,byte byteload2,byte byteload3,byte byteload4,byte byteload5);
// ------------------------------------------------------------------------

const uint8_t BitRate = 200;
/* Generate the PWM (42 MHz) */
const uint8_t Period42Mhz = 2;
const uint8_t Duty42Mhz = 1;
/* Generate the PWM ( 28 MHz) */
const uint8_t Period28Mhz = 3;
const uint8_t Duty28Mhz = 2;   //duty = 66% or change the MCK = 42 Mhz and period -> 2 duty ->
/* Generate the PWM ( 21 MHz) */
const uint8_t Period21Mhz = 4;
const uint8_t Duty21Mhz = 2;
uint8_t Address_Node0[8] = { 0, 1, 1, 0, 0, 1, 0, 1 };
bool state;

// ------------------------------------------------------------------------
// Trun on the Radio
// ------------------------------------------------------------------------
// Generate the PWM (42 MHz) as Carrier Frequency From 38.6.5 PWM Controller Operations //
// pin_traits_specialization(pwm_pin::PWML6_PC23, PIOC, PIO_PC23B_PWML6, ID_PIOC, PIO_PERIPH_B, PIO_DEFAULT,  PWM_CH6,true  );
bool Enable_CarrierPWM(uint8_t Period, uint8_t Duty) {
  /* Activate clock for PWM controller from PMC, PWM ID =36 ->*/
  REG_PMC_PCER1 = 1 << 4;
  // Activate peripheral functions for pin -> Datasheet 31.7.2 & 31.5.2&3)
  REG_PIOC_PDR |= CaINTxGPIO;
  REG_PIOC_ABSR |= CaINTxGPIO;
  /*   ----------------The following is for configure the PWM ----------------*/
  //38.7.1 Select the MCK (Master clock 84Mhz)
  REG_PWM_CLK = 0;
  //38.7.37 PWM Channel Mode Register PWM channel 6 (pin7) -> (CPOL = 0)  left-aligned
  REG_PWM_CMR6 = 0 << 9;
  //38.7.40 PWM Channel Period Register (16 bits -> Period / 84 = Frequency Output )
  REG_PWM_CPRD6 = Period;
  //38.7.38 PWM Channel Duty Cycle Register
  REG_PWM_CDTY6 = Duty;
  //38.7.2 PWM Enable Register
  REG_PWM_ENA = 1 << 6;
  return OnRadioFlag;
}

// Trun off the RF
bool Disable_CarrierPWM(void) {
  // Disable all GPIO & peripherals Configuration
  REG_PIOC_PDR = 0;
  REG_PIOC_ABSR = 0;
  // Disable the PWM clock and channel
  REG_PMC_PCDR1 = 1 << 4;
  REG_PWM_DIS = 1 << 6;

  return OffRadioFlag;
}

void Ascii_to_BinaryAarray(char ascii, uint8_t arr[8]) {

  byte mask = 0b00000001;
  for (int i = 0; i < 8; i++) {
    arr[i] = ascii & mask;
    arr[i] = arr[i] >> i;
    mask = mask << 1;
  }
}


/*send 32 HIGH LOW edges to synchronize with the receptor*/
void Send_sync(int cycles) {
  //sending a sync signal
  for (byte i = 0; i < cycles; i++) {
    Enable_CarrierPWM(Period42Mhz, Duty42Mhz);
    //digitalWrite(RF_PIN,HIGH);
    delayMicroseconds(BitRate);
    Disable_CarrierPWM();
    //digitalWrite(RF_PIN,LOW);
    delayMicroseconds(BitRate);
  }
  Enable_CarrierPWM(Period42Mhz, Duty42Mhz);
  //digitalWrite(RF_PIN,HIGH);
}

/*send 32 HIGH LOW edges to synchronize with the receptor*/
void Send_syncEnd(int cycles) {
  //sending a sync signal
  for (byte i = 0; i < cycles; i++) {
    Disable_CarrierPWM();
    //digitalWrite(RF_PIN,HIGH);
    delayMicroseconds(BitRate);
    Enable_CarrierPWM(Period42Mhz, Duty42Mhz);
    //digitalWrite(RF_PIN,LOW);
    delayMicroseconds(BitRate);
  }
  //digitalWrite(RF_PIN,HIGH);
}

/*send a byte but without sync; state is the current state of the ouput line*/
bool Send_load(byte start[], bool state) {

  for (byte i = 0; i < 8; i++) {
    //Serial.print(start[i]);
    if (start[i] == 1) {
      if (state == LOW) {
        delayMicroseconds(BitRate);
        state = Enable_CarrierPWM(Period42Mhz, Duty42Mhz);
        //digitalWrite(RF_PIN,HIGH);
        //state = HIGH;
      } else  //state==HIGH
      {
        delayMicroseconds(BitRate / 2);
        // digitalWrite(RF_PIN,LOW);
        Disable_CarrierPWM();
        delayMicroseconds(BitRate / 2);
        //digitalWrite(RF_PIN,HIGH);
        state = Enable_CarrierPWM(Period42Mhz, Duty42Mhz);
      }
    } else  //start[i]==0
    {
      if (state == LOW) {
        delayMicroseconds(BitRate / 2);
        //digitalWrite(RF_PIN,HIGH);
        Enable_CarrierPWM(Period42Mhz, Duty42Mhz);
        delayMicroseconds(BitRate / 2);
        // digitalWrite(RF_PIN,LOW);
        state = Disable_CarrierPWM();
      } else  //state==HIGH
      {
        delayMicroseconds(BitRate);
        state = Disable_CarrierPWM();
        // digitalWrite(RF_PIN,LOW);
      }
    }
  }
  return state;
}

/*send a sync signal + a start byte + load ; load is an array of 8 bit, no more no less !!*/
void Send_bytes(byte byteload0, byte byteload1,byte byteload2,byte byteload3,byte byteload4,byte byteload5) {

  byte Dataload0Arr[8];
  byte Dataload1Arr[8];
  byte Dataload2Arr[8];
  byte Dataload3Arr[8];
  byte Dataload4Arr[8];
  byte Dataload5Arr[8];

  Ascii_to_BinaryAarray(byteload0, Dataload0Arr);    //change ascii code to bits array
  Ascii_to_BinaryAarray(byteload1, Dataload1Arr);  //change ascii code to bits array
  Ascii_to_BinaryAarray(byteload2, Dataload2Arr); 
  Ascii_to_BinaryAarray(byteload3, Dataload3Arr); 
  Ascii_to_BinaryAarray(byteload4, Dataload4Arr); 
  Ascii_to_BinaryAarray(byteload5, Dataload5Arr);

  // Send 32 cycles for preamble
  Send_sync(4);
  //line must be high after sync
  state = HIGH;
  //send the start message
  state= Send_load(Address_Node0, state);
  // Serial.println();
  state = Send_load(Dataload0Arr, state);
  // Serial.println();
  state = Send_load(Dataload1Arr, state);
  // Serial.println();
  state = Send_load(Dataload2Arr, state);
  // Serial.println();
  state = Send_load(Dataload3Arr, state);
  // Serial.println();
  state = Send_load(Dataload4Arr, state);
  // Serial.println();
  Send_load(Dataload5Arr, state);
  //Serial.println();
  //Send_syncEnd(4);
  Disable_CarrierPWM();
}

void setup() {
  //Serial.begin(115200);
  pinMode(CaINSwitchGPIO, OUTPUT);  
  digitalWrite(CaINSwitchGPIO,HIGH);
  delay(3000);
}

void loop() {

 for (int i = 0; i < 30;) {
    Send_bytes('A' + i, '1' + i,'a' + i,'3' + i,'b' + i,'F' +i);
    i = i + 3;
    delay(4000);
 }

}
